#!/usr/bin/env python
# -*- coding:utf-8 -*-

import est.mode as mode

if __name__ == '__main__':
    mode.run()
    print('hhhhhh')
